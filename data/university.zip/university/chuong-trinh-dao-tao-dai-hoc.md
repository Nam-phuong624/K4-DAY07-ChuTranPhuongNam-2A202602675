---
doc_id: chuong-trinh-dao-tao-dai-hoc
title: "Danh mục các chương trình đào tạo bậc đại học tại ĐHQGHN"
source_url: https://vnu.edu.vn/dao-tao/chuong-trinh-dao-tao-bac-dai-hoc
retrieved_at: 2026-09-19
document_version: "2026.1"
audience: student
department: academic-affairs
category: academic-program
language: vi
---

# Danh mục các chương trình đào tạo bậc đại học tại ĐHQGHN

Dưới đây là danh mục chi tiết các chương trình đào tạo chuẩn và đặc thù bậc đại học của các trường đại học thành viên, trường trực thuộc ĐHQGHN:

| STT | Tên ngành, chuyên ngành đào tạo | CTĐT chuẩn | CTĐT đặc thù (*) | Tổng |
| --- | --- | --- | --- | --- |
| I. Trường Đại học Công nghệ |  |  |  |  |
| 1 | Công nghệ thông tin | 1 |  |  |
| 2 | Công nghệ thông tin (CTĐT CLC) |  | 1 |  |
| 3 | Công nghệ thông tin định hướng thị trường Nhật Bản | 1 |  |  |
| 4 | Kỹ thuật máy tính | 1 |  |  |
| 5 | Kỹ thuật Robot (CTĐT thí điểm) | 1 |  |  |
| 6 | Kỹ thuật năng lượng (CTĐT thí điểm) | 1 |  |  |
| 7 | Vật lý kỹ thuật | 1 |  |  |
| 8 | Cơ kỹ thuật | 1 |  |  |
| 9 | Công nghệ kỹ thuật xây dựng | 1 |  |  |
| 10 | Công nghệ Hàng không vũ trụ(CTĐT thí điểm) | 1 |  |  |
| 11 | Kỹ thuật điều khiển và tự động hóa | 1 |  |  |
| 12 | Công nghệ nông nghiệp(CTĐT thí điểm) | 1 |  |  |
| 13 | Công nghệ kỹ thuật cơ điện tử(CTĐT CLC) |  | 1 |  |
| 14 | Khoa học Máy tính (CTĐT CLC) |  | 1 |  |
| 15 | Hệ thống thông tin (CTĐT CLC) |  | 1 |  |
| 16 | Mạng máy tính và truyền thông dữ liệu (CTĐT CLC) |  | 1 |  |
| 17 | Công nghệ kỹ thuật điện tử - viễn thông (CTĐT CLC) |  | 1 |  |
| 18 | Trí tuệ nhân tạo | 1 |  |  |
| II. Trường Đại học Khoa học Tự nhiên |  |  |  |  |
| 1 | Toán học | 1 |  |  |
| 2 | Toán học (CTĐT tài năng) |  | 1 |  |
| 3 | Toán học (CTĐT tiên tiến) |  | 1 |  |
| 4 | Toán cơ |  |  |  |
| 5 | Toán - Tin | 1 |  |  |
| 6 | Khoa học Máy tính và thông tin(CTĐT thí điểm) | 1 |  |  |
| 7 | Khoa học dữ liệu (CTĐT thí điểm) | 1 |  |  |
| 8 | Vật lý học | 1 |  |  |
| 9 | Vật lý học (CTĐT tài năng) |  | 1 |  |
| 10 | Vật lý học (CTĐT chuẩn quốc tế) |  | 1 |  |
| 11 | Khoa học vật liệu | 1 |  |  |
| 12 | Công nghệ kỹ thuật hạt nhân | 1 |  |  |
| 13 | Kĩ thuật điện tử và tin học (CTĐT thí điểm) | 1 |  |  |
| 14 | Hóa học | 1 |  |  |
| 15 | Hóa học (CTĐT tài năng) |  | 1 |  |
| 16 | Hóa học (CTĐT tiên tiến) |  | 1 |  |
| 17 | Công nghệ kỹ thuật hóa học | 1 |  |  |
| 18 | Công nghệ kỹ thuật hóa học (CTĐT CLC) |  | 1 |  |
| 19 | Hóa dược (CTĐT CLC) |  | 1 |  |
| 20 | Sinh học | 1 |  |  |
| 21 | Sinh học (CTĐT chuẩn quốc tế) |  | 1 |  |
| 22 | Sinh học (CTĐT tài năng) |  | 1 |  |
| 23 | Công nghệ sinh học | 1 |  |  |
| 24 | Công nghệ sinh học (CTĐT CLC) |  | 1 |  |
| 25 | Địa lý tự nhiên | 1 |  |  |
| 26 | Địa lý tự nhiên (CTĐT CLC) |  | 1 |  |
| 27 | Khoa học thông tin địa không gian(CTĐT thí điểm) | 1 |  |  |
| 28 | Quản lý đất đai | 1 |  |  |
| 29 | Quản lý phát triển đô thị và bất động sản (CTĐT thí điểm) | 1 |  |  |
| 30 | Khoa học môi trường | 1 |  |  |
| 31 | Khoa học môi trường (CTĐT tiên tiến) |  | 1 |  |
| 32 | Khoa học môi trường (CTĐT CLC) |  | 1 |  |
| 33 | Công nghệ kỹ thuật môi trường | 1 |  |  |
| 34 | Công nghệ kỹ thuật môi trường(CTĐT CLC) |  | 1 |  |
| 35 | Khoa học và công nghệ thực phẩm(CTĐT thí điểm) | 1 |  |  |
| 36 | Khí tượng và khí hậu học | 1 |  |  |
| 37 | Hải dương học | 1 |  |  |
| 38 | Tài nguyên và môi trường nước(CTĐT thí điểm) | 1 |  |  |
| 39 | Địa chất học | 1 |  |  |
| 40 | Địa chất học(CTĐT CLC) |  | 1 |  |
| 41 | Địa chất học (CTĐT chuẩn quốc tế) |  | 1 |  |
| 42 | Kỹ thuật địa chất | 1 |  |  |
| 43 | Quản lý tài nguyên và môi trường | 1 |  |  |
| 44 | Khoa học đất | 1 |  |  |
| 45 | Khí tượng học (CTĐT CLC) |  | 1 |  |
| 46 | Thủy văn | 1 |  |  |
| 47 | Thủy văn (CTĐT CLC) |  | 1 |  |
| 48 | Hải dương học (CTĐT CLC) |  | 1 |  |
| 49 | Công nghệ quan trắc và giám sát tài nguyên môi trường (CTĐT thí điểm) | 1 |  |  |
| 50 | Sinh dược học |  |  |  |
|  | Môi trường, Sức khỏe và An toàn |  |  |  |
| III. Trường ĐH Khoa học Xã hội và Nhân văn |  |  |  |  |
| 1 | Báo chí | 1 |  |  |
| 2 | Báo chí (CTĐT CLC) |  | 1 |  |
| 3 | Chính trị học | 1 |  |  |
| 4 | Công tác xã hội | 1 |  |  |
| 5 | Đông Nam Á học | 1 |  |  |
| 6 | Đông phương học | 1 |  |  |
| 7 | Hàn Quốc học | 1 |  |  |
| 8 | Hán Nôm | 1 |  |  |
| 9 | Khoa học quản lý | 1 |  |  |
| 10 | Khoa học quản lý (CTĐT CLC) |  | 1 |  |
| 11 | Lịch sử | 1 |  |  |
| 12 | Lưu trữ học | 1 |  |  |
| 13 | Ngôn ngữ học | 1 |  |  |
| 14 | Nhân học | 1 |  |  |
| 15 | Nhật Bản học | 1 |  |  |
| 16 | Quan hệ công chúng | 1 |  |  |
| 17 | Quản lí thông tin | 1 |  |  |
| 18 | Quản lí thông tin (CTĐT CLC) |  | 1 |  |
| 19 | Quản trị dịch vụ du lịch và lữ hành | 1 |  |  |
| 20 | Quản trị khách sạn | 1 |  |  |
| 21 | Quản trị văn phòng | 1 |  |  |
| 22 | Quốc tế học | 1 |  |  |
| 23 | Quốc tế học (CTĐT CLC) |  | 1 |  |
| 24 | Tâm lý học | 1 |  |  |
| 25 | Thông tin - thư viện | 1 |  |  |
| 26 | Tôn giáo học | 1 |  |  |
| 27 | Triết học | 1 |  |  |
| 28 | Văn hóa học | 1 |  |  |
| 29 | Văn học | 1 |  |  |
| 30 | Việt Nam học | 1 |  |  |
| 31 | Xã hội học | 1 |  |  |
| IV. Trường Đại học Ngoại ngữ |  |  |  |  |
| 1 | Sư phạm tiếng Anh | 1 |  |  |
| 2 | Ngôn ngữ Anh (CTĐT CLC) |  | 1 |  |
| 3 | Ngôn ngữ Nga | 1 |  |  |
| 4 | Ngôn ngữ Pháp (CTĐT CLC) |  | 1 |  |
| 5 | Sư phạm tiếng Trung Quốc | 1 |  |  |
| 6 | Ngôn ngữ Trung Quốc (CTĐT CLC) |  | 1 |  |
| 7 | Sư phạm Tiếng Đức | 1 |  |  |
| 8 | Ngôn ngữ Đức (CTĐT CLC) |  | 1 |  |
| 9 | Sư phạm tiếng Nhật | 1 |  |  |
| 10 | Ngôn ngữ Nhật (CTĐT CLC) |  | 1 |  |
| 11 | Sư phạm tiếng Hàn Quốc | 1 |  |  |
| 12 | Ngôn ngữ Hàn Quốc (CTĐT CLC) |  | 1 |  |
| 13 | Ngôn ngữ Ảrập | 1 |  |  |
| 14 | Văn hóa truyền thông xuyên quốc gia |  |  |  |
| V. Trường Đại học Kinh tế |  |  |  |  |
| 1 | Quản trị kinh doanh (CTĐT CLC) |  | 1 |  |
| 2 | Tài chính - Ngân hàng (CTĐT CLC) |  | 1 |  |
| 3 | Kế toán (CTĐT CLC) |  | 1 |  |
| 4 | Kinh tế quốc tế (CTĐT CLC) |  | 1 |  |
| 5 | Kinh tế (CTĐT CLC) |  | 1 |  |
| 6 | Kinh tế phát triển (CTĐT CLC) |  | 1 |  |
| 7 | Quản trị kinh doanh (CTĐT dành cho các tài năng thể thao) |  | 1 |  |
| VI. Trường Đại học Giáo dục |  |  |  |  |
| 1 | Sư phạm Toán học | 1 |  |  |
| 2 | Sư phạm Vật lý | 1 |  |  |
| 3 | Sư phạm Hóa học | 1 |  |  |
| 4 | Sư phạm Sinh học | 1 |  |  |
| 5 | Sư phạm khoa học tự nhiên | 1 |  |  |
| 6 | Sư phạm Ngữ văn | 1 |  |  |
| 7 | Sư phạm Lịch sử | 1 |  |  |
| 8 | Sư phạm lịch sử và địa lí | 1 |  |  |
| 9 | Quản trị trường học | 1 |  |  |
| 10 | Quản trị công nghệ giáo dục | 1 |  |  |
| 11 | Quản trị chất lượng giáo dục | 1 |  |  |
| 12 | Tham vấn học đường | 1 |  |  |
| 13 | Khoa học giáo dục | 1 |  |  |
| 14 | Giáo dục tiểu học | 1 |  |  |
| 15 | Giáo dục mầm non | 1 |  |  |
| VII. Trường Đại học Việt Nhật |  |  |  |  |
| 1 | Nhật Bản học | 1 |  |  |
| 2 | Khoa học và Kỹ thuật máy tính (CTĐT CLC) |  | 1 |  |
| 3 | Nông nghiệp thông minh và bền vững (CTĐT CLC) |  | 1 |  |
| 4 | Kỹ thuật xây dựng (CTĐT CLC) |  | 1 |  |
| 5 | Kỹ thuật cơ điện tử |  |  |  |
| 6 | Công nghệ thực phẩm và sức khỏe |  |  |  |
| VIII. Trường ĐH Y Dược |  |  |  |  |
| 1 | Y khoa | 1 |  |  |
| 2 | Dược học | 1 |  |  |
| 3 | Răng - Hàm - Mặt (CTĐT CLC) |  | 1 |  |
| 4 | Điều dưỡng | 1 |  |  |
| 5 | Kĩ thuật hình ảnh y học | 1 |  |  |
| 6 | Kĩ thuật xét nghiệm y học | 1 |  |  |
| IX. Trường Quốc tế |  |  |  |  |
| 1 | Kinh doanh quốc tế (CTĐT thí điểm) |  | 1 |  |
| 2 | Kế toán, phân tích và kiểm toán(CTĐT thí điểm) |  | 1 |  |
| 3 | Hệ thống thông tin quản lí(CTĐT thí điểm) |  | 1 |  |
| 4 | Phân tích dữ liệu kinh doanh(CTĐT thí điểm) |  | 1 |  |
| 5 | Marketing (CTĐT cấp 2 bằng ĐH của ĐHQGHN và trường ĐH HELP – Malaysia) |  | 1 |  |
| 6 | Quản lý (CTĐT cấp 2 bằng ĐH của ĐHQGHN và trường ĐH Keuka – Hoa Kỳ) |  | 1 |  |
| 7 | Tin học và kĩ thuật máy tính (CTĐT LKQT do ĐHQGHN cấp bằng) |  | 1 |  |
| 8 | Ngôn ngữ Anh (chuyên sâu Kinh doanh và Công nghệ thông tin) |  | 1 |  |
| 9 | Kỹ sư Tự động hóa và tin học |  | 1 |  |
| 10 | Công nghệ thông tin ứng dụng |  | 1 |  |
| 11 | Công nghệ tài chính và kinh doanh số |  | 1 |  |
| 12 | Kỹ thuật hệ thống công nghiệp và Logistics |  | 1 |  |
| X. Trường Quản trị và Kinh doanh |  |  |  |  |
| 1 | Quản trị doanh nghiệp và công nghệ |  | 1 |  |
| 2 | Marketing và Truyền thông |  | 1 |  |
| 3 | Quản trị Nhân lực và Nhân tài |  | 1 |  |
| 4 | Quản trị và An ninh |  | 1 |  |
| XI. Trường Đại học Luật |  |  |  |  |
| 1 | Luật | 1 |  |  |
| 2 | Luật (CTĐT CLC) |  | 1 |  |
| 3 | Luật kinh doanh | 1 |  |  |
| 4 | Luật thương mại quốc tế | 1 |  |  |
| XII. Khoa Các khoa học liên ngành |  |  |  |  |
| 1 | Quản trị thương hiệu(CTĐT thí điểm) |  | 1 |  |
| 2 | Quản trị tài nguyên và di sản(CTĐT thí điểm) |  | 1 |  |
| 3 | Quản lý giải trí và sự kiện |  | 1 |  |
| 4 | Quản trị đô thị thông minh và bền vững |  | 1 |  |
| 5 | Thiết kế sáng tạo |  |  |  |
